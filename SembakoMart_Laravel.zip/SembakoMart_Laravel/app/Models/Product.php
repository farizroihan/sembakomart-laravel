<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Product extends Model {protected $fillable=['category_id','name','slug','description','price','stock','image','is_active'];protected function casts():array{return ['price'=>'integer','stock'=>'integer','is_active'=>'boolean'];}public function category(){return $this->belongsTo(Category::class);}}